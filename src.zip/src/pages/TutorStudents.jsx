import React, { useState, useEffect } from 'react';
import { TutoringSession } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, MessageCircle, Calendar, Star } from 'lucide-react';
import { format } from 'date-fns';

export default function TutorStudents() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const currentUser = await User.me();

        // Fetch all sessions for the tutor (no server-side sort string)
        const sessionData = await TutoringSession.filter({ tutor_id: currentUser.id });

        // Sort newest first on the client (if needed)
        const sessions = [...sessionData].sort(
          (a, b) => new Date(b.scheduled_date || 0) - new Date(a.scheduled_date || 0)
        );

        // Group sessions by student_id (fallback to student_email if no id)
        const byStudent = new Map();
        for (const s of sessions) {
          const key = s.student_id || s.student_email || `unknown-${(s.id || Math.random()).toString()}`;
          const bucket = byStudent.get(key) || [];
          bucket.push(s);
          byStudent.set(key, bucket);
        }

        // Build student rows with stats using data embedded in sessions
        const rows = Array.from(byStudent.entries()).map(([key, sess]) => {
          const latest = sess[0]; // sessions already sorted desc
          const fullName =
            latest.student_full_name ||
            latest.student_name ||
            'Unknown Student';
          const email = latest.student_email || '';

          const completed = sess.filter(x => x.status === 'completed');
          const rated = sess.filter(x => typeof x.student_rating === 'number' && x.student_rating > 0);

          const averageRating =
            rated.length > 0
              ? rated.reduce((sum, x) => sum + (x.student_rating || 0), 0) / rated.length
              : 0;

          return {
            id: key,
            full_name: fullName,
            email,
            subjects: Array.from(new Set(sess.map(x => x.subject).filter(Boolean))),
            totalSessions: sess.length,
            completedSessions: completed.length,
            averageRating,
            lastSession: latest,
          };
        });

        setStudents(rows);
      } catch (error) {
        console.error('Error loading students:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Users className="w-8 h-8 text-purple-600" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            My Students
          </h1>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Student Overview</CardTitle>
          </CardHeader>
          <CardContent>
            {students.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Subjects</TableHead>
                    <TableHead>Total Sessions</TableHead>
                    <TableHead>Completed</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Last Session</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map(student => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{student.full_name}</div>
                          {student.email && (
                            <div className="text-sm text-gray-500">{student.email}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {student.subjects.length > 0 ? (
                            student.subjects.map(subject => (
                              <Badge key={subject} variant="outline" className="text-xs">
                                {subject}
                              </Badge>
                            ))
                          ) : (
                            <span className="text-sm text-gray-400">—</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{student.totalSessions}</TableCell>
                      <TableCell>{student.completedSessions}</TableCell>
                      <TableCell>
                        {student.averageRating > 0 ? (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-400 fill-current" />
                            <span>{student.averageRating.toFixed(1)}</span>
                          </div>
                        ) : (
                          <span className="text-gray-400">No ratings</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {student.lastSession?.scheduled_date
                          ? format(new Date(student.lastSession.scheduled_date), 'MMM dd, yyyy')
                          : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm" title="Message">
                            <MessageCircle className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" title="Schedule">
                            <Calendar className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Students Yet</h3>
                <p className="text-gray-600">Students who book sessions with you will appear here.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
